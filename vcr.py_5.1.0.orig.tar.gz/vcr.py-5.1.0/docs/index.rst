.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 3

   installation
   usage
   configuration
   advanced
   api
   debugging
   contributing
   changelog


==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
