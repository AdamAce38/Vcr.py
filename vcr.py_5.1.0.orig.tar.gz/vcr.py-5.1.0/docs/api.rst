API
===

:mod:`~vcr.config`
------------------

.. automodule:: vcr.config
   :members:
   :special-members: __init__

:mod:`~vcr.cassette`
--------------------

.. automodule:: vcr.cassette
   :members:
   :special-members: __init__

:mod:`~vcr.matchers`
--------------------

.. automodule:: vcr.matchers
   :members:
   :special-members: __init__

:mod:`~vcr.filters`
-------------------

.. automodule:: vcr.filters
   :members:
   :special-members: __init__

:mod:`~vcr.request`
-------------------

.. automodule:: vcr.request
   :members:
   :special-members: __init__

:mod:`~vcr.serialize`
---------------------

.. automodule:: vcr.serialize
   :members:
   :special-members: __init__

:mod:`~vcr.patch`
-----------------

.. automodule:: vcr.patch
   :members:
   :special-members: __init__
